- Installation Guides

  - [Prerequisites](prerequisites.md)
  - [Using source code](using-source-code.md)
  - [Using docker](using-docker.md)

- Help
  - [Cezerin Community Site](https://cezerin.org)
  - [Telegram Chat: Cezerin](https://t.me/cezerin)
